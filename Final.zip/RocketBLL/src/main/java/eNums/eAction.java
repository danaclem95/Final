package eNums;

public enum eAction {
	CalculatePayment;
}
